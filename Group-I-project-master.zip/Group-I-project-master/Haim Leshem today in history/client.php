<?php
include "TodayinHistory.php";
$obj = new TodayinHistory();
echo $obj->passJson()
?>