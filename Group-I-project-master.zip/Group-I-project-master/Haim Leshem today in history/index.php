<html>
<head>
    <script src="HistorySctipt.js"></script>
    <link rel="stylesheet" href="hist.css"/>
</head>
<body>

<div id="History"></div>

</body>
</html>