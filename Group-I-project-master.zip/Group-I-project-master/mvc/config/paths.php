<?php

define('URL','http://localhost/project/mvc/');