<?php
require  'libs/Bootstrap.php';
require  'libs/Controller.php';
require  'libs/View.php';
require  'libs/Model.php';
require  'config/paths.php';
require  'config/database.php';
//Library
require  'libs/Database.php';
require  'libs/Session.php';
$app=new Bootstrap();